import json
import base64
import gzip 
import boto3
import os

SNS_TOPIC_ARN = os.getenv('SNS_TOPIC_ARN')

client = boto3.client('sns')

def lambda_handler(event, context):

    send_sns(decode(event['awslogs']['data']))
    
    return {
        'statusCode': 200,
        'body': json.dumps('Send to sns!')
    }
    
def decode(data): 
    data_bytes = data.encode("utf-8")
    base64_decode_bytes = base64.b64decode(data_bytes)
    gzip_decode_bytes = gzip.decompress(base64_decode_bytes)
    return gzip_decode_bytes.decode("utf-8")
    
def send_sns(msg: str):
    # format message
    json_object = json.loads(msg)
    msg = json.dumps(json_object, indent=4)
    
    # send
    response = client.publish(TopicArn=SNS_TOPIC_ARN, Message=msg)
    print(response) 